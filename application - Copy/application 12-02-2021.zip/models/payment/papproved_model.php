<?php
class Papproved_model extends CI_Model {
  public function get_count(){
    $condition=' ';
    if($_GET){
      if($this->input->get('applications_no')!=''){
        $applications_no=$this->input->get('applications_no');
        $condition=$condition."  AND pm.applications_no='$applications_no' ";
      }
      if($this->input->get('pay_to_id')!='All'){
        $pay_to_id=$this->input->get('pay_to_id');
        $condition=$condition."  AND pm.pay_to_id='$pay_to_id' ";
      }
      if($this->input->get('from_date')!=''&&$this->input->get('to_date') !=' '){
        $from_date=$this->input->get('from_date');
        $to_date=$this->input->get('to_date');
        $condition.=" AND pm.applications_date BETWEEN '$from_date' AND '$to_date'";
      }
     }
    $department_id=$this->session->userdata('department_id');
    $query=$this->db->query("SELECT pm.*,d.department_name,
    	u.user_name, p.pay_to_name
      FROM  payment_application_master pm 
      LEFT JOIN department_info d ON(pm.department_id=d.department_id)
      LEFT JOIN payment_to_info p ON(pm.pay_to_id=p.pay_to_id) 
      LEFT JOIN user u ON(u.id=pm.prepared_by) 
      WHERE pm.to_department_id=$department_id 
      AND pm.status>=3 $condition");
       
     $data = count($query->result());
     return $data;
    }
  function lists($limit,$start) {
    $condition=' ';
    if($_GET){
      if($this->input->get('applications_no')!=''){
        $applications_no=$this->input->get('applications_no');
        $condition=$condition."  AND pm.applications_no='$applications_no' ";
      }
    
      if($this->input->get('pay_to_id')!='All'){
        $pay_to_id=$this->input->get('pay_to_id');
        $condition=$condition."  AND pm.pay_to_id='$pay_to_id' ";
      }
      if($this->input->get('from_date')!=''&&$this->input->get('to_date') !=' '){
        $from_date=$this->input->get('from_date');
        $to_date=$this->input->get('to_date');
        $condition.=" AND pm.applications_date BETWEEN '$from_date' AND '$to_date'";
      }
     }
  $department_id=$this->session->userdata('department_id');
    $result=$this->db->query("SELECT pm.*,d.department_name,
    	u.user_name, p.pay_to_name
      FROM  payment_application_master pm 
      LEFT JOIN department_info d ON(pm.department_id=d.department_id)
      LEFT JOIN payment_to_info p ON(pm.pay_to_id=p.pay_to_id) 
      LEFT JOIN user u ON(u.id=pm.prepared_by) 
      WHERE pm.to_department_id=$department_id   
      AND pm.status>=3 
      $condition
      ORDER BY pm.payment_id 
      DESC LIMIT $start,$limit")->result();
 
    return $result;
  }

   function approved($payment_id) {
    $data=array();
        $data['status']=4;
        $data['approved_by']=$this->session->userdata('user_id');
        $data['approved_date']=date('Y-m-d');
        $this->db->WHERE('payment_id',$payment_id);
        $query=$this->db->Update('payment_application_master',$data);
        return $query;
     }


  
}
