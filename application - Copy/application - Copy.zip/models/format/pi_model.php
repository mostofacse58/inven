<?php
class Pi_model extends CI_Model {
	public function get_count(){
    $condition=' ';
    if($_GET){
      if($this->input->get('pi_no')!=''){
        $pi_no=$this->input->get('pi_no');
        $condition=$condition."  AND pm.pi_no='$pi_no' ";
      }
      if($this->input->get('department_id')!='All'){
        $department_id=$this->input->get('department_id');
        $condition=$condition."  AND pm.department_id='$department_id' ";
      }
     }
    $department_id1=$this->session->userdata('department_id');
      $query=$this->db->query("SELECT pm.*,pt.p_type_name,u.user_name
      FROM  pi_master pm 
      LEFT JOIN purchase_type pt ON(pm.purchase_type_id=pt.purchase_type_id)
      LEFT JOIN user u ON(u.id=pm.requested_by) 
      WHERE pm.pi_status>=4 AND pm.responsible_department=15 $condition");
      $data = count($query->result());
      return $data;
    }
    function lists($limit,$start) {
        $condition=' ';
        if($_GET){
          if($this->input->get('pi_no')!=''){
            $pi_no=$this->input->get('pi_no');
            $condition=$condition."  AND pm.pi_no='$pi_no' ";
          }
          if($this->input->get('department_id')!='All'){
          $department_id=$this->input->get('department_id');
          $condition=$condition."  AND pm.department_id='$department_id' ";
        }
        }
        $department_id1=$this->session->userdata('department_id');
        $result=$this->db->query("SELECT pm.*,pt.p_type_name,u.user_name,d.department_name,dr.deptrequisn_no       
          FROM  pi_master pm 
          LEFT JOIN purchase_type pt ON(pm.purchase_type_id=pt.purchase_type_id)
          LEFT JOIN department_info d ON(pm.department_id=d.department_id)
          LEFT JOIN deptrequisn_master dr ON(pm.deptrequisn_id=dr.deptrequisn_id) 
          LEFT JOIN user u ON(u.id=pm.requested_by) 
          WHERE pm.pi_status>=4 AND pm.responsible_department=15 $condition
          ORDER BY pm.pi_id DESC LIMIT $start,$limit")->result();
        return $result;
    }
    function get_info($pi_id){
         $result=$this->db->query("SELECT pm.*,pt.p_type_name,u.user_name,d.department_name,dr.deptrequisn_no 
          FROM  pi_master pm 
          LEFT JOIN purchase_type pt ON(pm.purchase_type_id=pt.purchase_type_id)
          LEFT JOIN department_info d ON(pm.department_id=d.department_id)
          LEFT JOIN deptrequisn_master dr ON(pm.deptrequisn_id=dr.deptrequisn_id) 
          LEFT JOIN user u ON(u.id=pm.requested_by) 
          WHERE pm.pi_id=$pi_id")->row();
        return $result;
    }
    function save($pi_id) {
        $data=array();
        $data['purchase_type_id']=$this->input->post('purchase_type_id');
        $data['pi_no']=$this->input->post('pi_no');
        $data['pi_date']=alterDateFormat($this->input->post('pi_date'));
        $data['demand_date']=alterDateFormat($this->input->post('demand_date'));
        $data['promised_date']=alterDateFormat($this->input->post('promised_date'));
        $data['user_id']=$this->session->userdata('user_id');
        $data['requested_by']=$this->session->userdata('user_id');
        $data['department_id']=$this->input->post('department_id');
        $data['responsible_department']=15;
        $data['create_date']=date('Y-m-d');
        ////////////////////////////////////////
        $product_id=$this->input->post('product_id');
        $material_code=$this->input->post('material_code');
        $product_name=$this->input->post('product_name');
        $specification=$this->input->post('specification');
        $required_qty=$this->input->post('required_qty');
        $stock_qty=$this->input->post('stock_qty');
        $purchased_qty=$this->input->post('purchased_qty');
        $remarks=$this->input->post('remarks');
        $i=0;
        if($pi_id==FALSE){
        $query=$this->db->insert('pi_master',$data);
        $pi_id=$this->db->insert_id();
        }else{
          $this->db->WHERE('pi_id',$pi_id);
          $query=$this->db->UPDATE('pi_master',$data);
          $this->db->WHERE('pi_id',$pi_id);
          $this->db->delete('pi_item_details');
        } 
        foreach ($product_id as $value) {
           $data1['product_id']=$value;
           $data1['pi_id']=$pi_id;
           $data1['material_code']=$material_code[$i];
           $data1['product_name']=$product_name[$i];
           $data1['specification']=$specification[$i];
           $data1['required_qty']=$required_qty[$i];
           $data1['stock_qty']=$stock_qty[$i];
           $data1['purchased_qty']=$purchased_qty[$i];
           $data1['remarks']=$remarks[$i];
           $data1['department_id']=$this->input->post('department_id');
           $query=$this->db->insert('pi_item_details',$data1);
           $i++;
         }
        return $query;
    }
  
    function delete($pi_id) {
      $this->db->WHERE('pi_id',$pi_id);
      $query=$this->db->delete('pi_item_details');
      $this->db->WHERE('pi_id',$pi_id);
      $query=$this->db->delete('pi_master');
      return $query;
     }
  public function getDetails($pi_id=''){
   $result=$this->db->query("SELECT p.*,c.category_name,u.unit_name,pud.*
        FROM pi_item_details pud
        LEFTLEFT JOIN product_info p ON(pud.product_id=p.product_id)
        LEFT JOIN category_info c ON(p.category_id=c.category_id)
        LEFT JOIN product_unit u ON(p.unit_id=u.unit_id)
        WHERE pud.pi_id=$pi_id 
        ORDER BY p.product_name ASC")->result();
   return $result;
  }
 function getPIProduct($department_id,$term) {
    $result=$this->db->query("SELECT p.*,c.category_name,u.unit_name
     FROM product_info p
      INNER JOIN category_info c ON(p.category_id=c.category_id)
      INNER JOIN product_unit u ON(p.unit_id=u.unit_id)
      WHERE p.department_id=$department_id 
      AND (p.product_code LIKE '%$term%' or p.product_name LIKE '%$term%') 
      ORDER BY p.product_name ASC")->result();
    return $result;
    }
   function approved($pi_id) {
      $data=array();
      $data['pi_status']=5;
      $data['approved_by']=$this->session->userdata('user_id');
      $this->db->WHERE('pi_id',$pi_id);
      $query=$this->db->Update('pi_master',$data);
      return $query;
     }
  
}
