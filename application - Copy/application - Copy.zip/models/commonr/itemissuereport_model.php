<?php
class Itemissuereport_model extends CI_Model {
	
	 function reportrResult($category_id,$department_id,$take_department_id,$product_code,$from_date,$to_date){
    $condition='';
    if($category_id!='All'){
    $condition.=" AND p.category_id=$category_id ";
    }
    if($take_department_id!='All'){
    $condition.=" AND sim.take_department_id=$take_department_id ";
    }
    if($product_code!=''){
      $condition.=" AND p.product_code='$product_code' ";
    }
    if($from_date!=''&&$to_date !=' '){
      $condition.=" AND sim.issue_date BETWEEN '$from_date' AND '$to_date'";
    }
    $result=$this->db->query("SELECT p.*,c.category_name,e.employee_name,
          iid.*,sim.issue_date,u.unit_name,
          l.location_name,sim.employee_id,d.department_name
          FROM item_issue_detail iid
          INNER JOIN  store_issue_master sim ON(iid.issue_id=sim.issue_id)
          INNER JOIN  product_info p ON(iid.product_id=p.product_id)
          INNER JOIN category_info c ON(p.category_id=c.category_id)
          LEFT JOIN department_info d ON(sim.take_department_id=d.department_id)
          LEFT JOIN location_info l ON(sim.location_id=l.location_id)
          LEFT JOIN employee_idcard_info e ON(sim.employee_id=e.employee_cardno)
          LEFT JOIN product_unit u ON(p.unit_id=u.unit_id)
          WHERE p.product_type=2 AND p.machine_other=2 
          AND sim.department_id=$department_id 
          $condition
          ORDER BY sim.issue_date ASC")->result();
        return $result;
          
	}
 


}