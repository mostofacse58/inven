<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Diferentupdate extends CI_Controller {
	function __construct(){
        parent::__construct();
        
     }
    
    function index(){
        $result=$this->db->query("SELECT p.*
          FROM  product_info p   
          WHERE p.product_type=2 
          ORDER BY p.product_id ASC")->result();
        foreach ($result as  $value) {

        $stock=$this->look_up_model->get_sparesStock($value->product_id);
        $data['main_stock']=$stock;
        $this->db->WHERE('product_id',$value->product_id);
        $query=$this->db->update('product_info',$data);
        }
        echo "done";
    }
    function priceupdate(){
      // $result=$this->db->query("SELECT id.*,p.*
      //     FROM  item_issue_detail id,product_info p   
      //     WHERE p.product_type=2 AND p.product_id=id.product_id 
      //     AND p.department_id=3 AND id.item_issue_detail_id>=17623
      //     AND id.item_issue_detail_id<=22211
      //     ORDER BY id.issue_id ASC")->result();
        $result=$this->db->query("SELECT id.*,p.*
          FROM  item_issue_detail id,product_info p   
          WHERE p.product_type=2 AND p.product_id=id.product_id 
          AND p.department_id=3 AND p.unit_price<1 AND p.medical_yes=1
          ORDER BY id.issue_id ASC")->result();

        foreach ($result as  $value) {
        $data['unit_price']=$value->unit_price;
        $data['sub_total']=$value->unit_price*$value->quantity;
        echo "$value->item_issue_detail_id <br>";
        echo $value->unit_price*$value->quantity;exit();
        //$this->db->WHERE('item_issue_detail_id',$value->item_issue_detail_id);
        //$query=$this->db->update('item_issue_detail',$data);
        }
      echo "done";
    }
    function changecode(){
        $result=$this->db->query("SELECT p.*
          FROM  product_detail_info p   
          WHERE p.department_id=3 AND p.machine_other=2
          ORDER BY p.product_detail_id ASC")->result();
        $code_count=0;
        foreach ($result as  $value) {
        $data['ventura_code']='ADMIN'.str_pad($code_count + 1, 6, '0', STR_PAD_LEFT);
        $data['code_count']=$code_count + 1;
        $this->db->WHERE('product_detail_id',$value->product_detail_id);
        $query=$this->db->update('product_detail_info',$data);
        $code_count++;
        }
        echo "done";
        /// Machine id=6341
    }

   


 }