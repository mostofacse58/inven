<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Monthlystatement extends My_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('medical/monthlystatement_model');
     }
    function SearchForm(){
        if ($this->session->userdata('user_id')) {
        $data['heading']='Medical statement (Monthly)';
		$data['clist']=$this->look_up_model->getCategory(12);
        $data['dlist']=$this->look_up_model->departmentList();
	    $data['display']='medical/monthlystatement';
        $this->load->view('admin/master',$data);
        } else {
           redirect("logincontroller");
        }
    }

    function reportrResult(){
       if ($this->session->userdata('user_id')) {
        $data['heading']='Medical statement (Monthly) ';
        $data['dlist']=$this->look_up_model->departmentList();
        $this->form_validation->set_rules('department_id','department Name','trim');
        $this->form_validation->set_rules('from_date','Date','trim');
        $this->form_validation->set_rules('to_date','date','trim');
        if ($this->form_validation->run() == TRUE) {
        $category_id=$this->input->post('category_id');
        $department_id=$this->input->post('department_id');
        $data['department_id']=$this->input->post('department_id');
        $data['from_date']=alterDateFormat($this->input->post('from_date'));
        $data['to_date']=alterDateFormat($this->input->post('to_date'));
        $data['resultdetail']=$this->monthlystatement_model->reportrResult($department_id,$data['from_date'],$data['to_date']);
        $data['display']='medical/monthlystatement';
        $this->load->view('admin/master',$data);
        }else{
        $data['display']='medical/monthlystatement';
        $this->load->view('admin/master',$data);
        }
        } else {
           redirect("logincontroller");
        } 
    }
    function downloadExcel($department_id=FALSE,$from_date=FALSE,$to_date=FALSE) {
        $data['heading']='Medical statement (Monthly) ';
        $data['from_date']=$from_date;
        $data['to_date']=$to_date;
        $data['resultdetail']=$this->monthlystatement_model->reportrResult($department_id,$from_date,$to_date);
        $this->load->view('medical/monthlystatementExcel',$data);
    }
    function downloadPdf($category_id=FALSE,$rack_id=FALSE,$box_id=FALSE,$product_code=FALSE) {
    if ($this->session->userdata('user_id')) {
    $data['heading']='Medical statement (Monthly) ';
    $data['category_id']=$category_id;
    $data['product_code']=$product_code;
    $data['rack_id']=$rack_id;
    $data['resultdetail']=$this->monthlystatement_model->reportrResult($category_id,$rack_id,$box_id,$product_code);
    $pdfFilePath='sparesIssuePdf'.date('Y-m-d H:i').'.pdf';
    $this->load->library('mpdf');
    $mpdf = new mPDF('bn','A4','','','15','15','30','18');
    $header = $this->load->view('header', $data, true);
    $html=$this->load->view('medical/itemissuePdf', $data, true);
    $mpdf->setHtmlHeader($header);
    $mpdf->pagenumPrefix = '  Page ';
    $mpdf->pagenumSuffix = ' - ';
    $mpdf->nbpgPrefix = ' out of ';
    $mpdf->nbpgSuffix = '';
    $mpdf->setFooter('{DATE H:i:s j/m/Y}{PAGENO}{nbpg}');
    $mpdf->WriteHTML($html);
    $mpdf->Output();
    } else {
       redirect("logincontroller");
    }
    }
    
}