<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cronjob extends CI_Controller {
  function __construct() {
	  parent::__construct();
  }

 function requisitiondata(){
		$rplists=$this->db->query("SELECT r.*,rd.* 
      FROM requisition_item_details rd,requisition_master r 
      WHERE r.requisition_id=rd.requisition_id AND rd.issue_status=1")->result();
     // print_r($rplists); exit();

		foreach ($rplists as  $value){
        $iqty=$this->look_up_model->getIssueTotalQty($value->requisition_no,$value->product_id);
        if($iqty>0){

          $data=array();
          $data['issued_qty']=$iqty;
          if($iqty==$value->required_qty){
            $data['issue_status']=2;
          }

      $this->db->WHERE('requisition_detail_id',$value->requisition_detail_id);
      $this->db->UPDATE('requisition_item_details',$data);
        }
      exit();
		
     }
    }
	

	
}