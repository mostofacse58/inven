<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Checkmachinedetail extends My_Controller {
	function __construct()
    {
        parent::__construct();
        $this->load->model('me/checkmachinedetail_model');
     }
    
    function index(){
        if ($this->session->userdata('user_id')) {
        $data['heading']='Checking Machine Detail';
        $data['display']='me/checkmDetails';
        $this->load->view('admin/master',$data);
        } else {
           redirect("logincontroller");
        }
    	
    }
    public  function forms(){
      if($this->session->userdata('user_id')){
        $data['heading']='Checking Machine Detail';
        $data['display']='admin/printform';
        $this->load->view('admin/master',$data);
        }else{
        redirect("admin/index");
      }
    }

  public  function search(){
    if($this->session->userdata('user_id')){
    $tpm_serial_code=$this->input->post('tpm_serial_code');
    $data['info']=$this->checkmachinedetail_model->search();
    $data['details']=$this->checkmachinedetail_model->getdowntime();
    $data['spareslist']=$this->checkmachinedetail_model->getUseSparesList();
    $data['heading']='Checking Machine Detail';
    $data['display']='me/checkmDetails';
    $this->load->view('admin/master',$data);
    }else{
    redirect("admin/index");
  }
}
function showbar(){
    if ($this->session->userdata('user_id')) {
        $data['details']=$this->checkmachinedetail_model->prints();
        $this->load->view('admin/qcode',$data);
        } else {
           redirect("logincontroller");
        }
}
function prints(){
        if ($this->session->userdata('user_id')) {
        $data['details']=$this->checkmachinedetail_model->prints();
        $this->load->view('admin/qcode',$data);
        } else {
           redirect("logincontroller");
        }
        
    }


 }