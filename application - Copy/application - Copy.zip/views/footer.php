<hr>
<div style="width:100%;overflow:hidden;font-size: 16px;color: #000;text-align:center">
 <p style="margin:0;text-align:center">
 	<b><?php echo  $this->session->userdata('caddress'); ?></b></p>
 </div>

