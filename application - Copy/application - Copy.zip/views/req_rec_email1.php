<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear , <br>
Good day. You have Receive one Purchase Indent(PI NO: <?php echo $info->pi_no; ?>) from <?php echo $info->department_name ; ?> department. please check. <br>
<a href="<?php echo base_url(); ?>">Click for Login</a>
<br><br>
Thanks by <br>
Ventura BD IT <br><br>
This is auto generated email from Ventura Inventory Management Software. No Need to Reply.
</body>
</html>