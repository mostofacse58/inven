<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Po extends My_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('format/purhrequisn_model');
        $this->load->model('format/po_model');
        $this->load->model('format/requisition_model');
     }
    
    function lists(){
    if($this->session->userdata('user_id')) {
    $data=array();
    if($this->input->post('perpage')!='') $perpage=$this->input->post('perpage'); else $perpage=10;
      ////////////////////////////////////
      $this->load->library('pagination');
      $config['base_url']=base_url().'format/po/lists/';
      $config["uri_segment"] = 4;
      $config['total_rows'] = $this->po_model->get_count();
      $total_rows=$config['total_rows'];
      $config['per_page'] = $perpage;
      $choice = $config["total_rows"] / $config["per_page"];
      $config["num_links"] = 2;
      $config['full_tag_open'] = '<ul class="pagination pagination-sm pull-right">';
      $config['full_tag_close'] = '</ul>';
      $config['first_link'] = 'First';
      $config['last_link'] = 'Last';
      $config['first_tag_open'] = '<li>';
      $config['first_tag_close'] = '</li>';
      $config['prev_link'] = '<span aria-hidden="true">&laquo Prev</span>';
      $config['prev_tag_open'] = '<li class="prev">';
      $config['prev_tag_close'] = '</li>';
      $config['next_link'] = '<span aria-hidden="true">Next »</span>';
      $config['next_tag_open'] = '<li>';
      $config['next_tag_close'] = '</li>';
      $config['last_tag_open'] = '<li>';
      $config['last_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="active"><a href="#">';
      $config['cur_tag_close'] = "</a></li>";
      $config['num_tag_open'] = '<li>';
      $config['num_tag_close'] = '</li>';
      ////////////////////////////////////////
      $this->pagination->initialize($config); 
      $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
      $pagination = $this->pagination->create_links();
      $data['pagination']='<p>We have ' . $total_rows . ' records in ' . $choice . ' pages ' . $pagination . '</p>';      
      $data['lists']=$this->po_model->lists($config["per_page"],$data['page'] );
      $data['dlist']=$this->look_up_model->departmentList();
      $data['slist']=$this->look_up_model->getSupplier();
      ////////////////////////////////////////
      $data['heading']='PO/WO Lists';
      $data['display']='format/po_lists';
      $this->load->view('admin/master',$data);
      } else {
        redirect("logincontroller");
      }
  }

function add(){
    if($this->session->userdata('user_id')) {
      $data['collapse']='YES';
      $data['heading']='Add PO';
      $data['department_id']=$this->session->userdata('department_id');
      $data['clist']=$this->look_up_model->clist();
      $data['ptlist']=$this->look_up_model->getPOType();
      $data['slist']=$this->look_up_model->getSupplier();
      $data['dlist']=$this->look_up_model->departmentList();
      $data['plist']=$this->look_up_model->payment_term();
      $data['display']='format/addpo';
      $this->load->view('admin/master',$data);
    }else{
      redirect("logincontroller");
    }
  }
  function edit($po_id){
    if ($this->session->userdata('user_id')) {
      $data['collapse']='YES';
      $data['heading']='Edit PO';
      $data['department_id']=$this->session->userdata('department_id');
      $data['ptlist']=$this->look_up_model->getPOType();
      $data['clist']=$this->look_up_model->clist();
      $data['info']=$this->po_model->get_info($po_id);
      $data['dlist']=$this->look_up_model->departmentList();
      $data['slist']=$this->look_up_model->getSupplier();
      $data['plist']=$this->look_up_model->payment_term();
      $data['detail']=$this->po_model->getDetails($po_id);
      $data['display']='format/addpo';
      $this->load->view('admin/master',$data);
      } else {
         redirect("logincontroller");
      }
  }
  function prtopo($requisition_id){
      $data['collapse']='YES';
      $data['heading']='Edit PO';
      $data['ptlist']=$this->look_up_model->getPOType();
      $data['clist']=$this->look_up_model->clist();
      $data['dlist']=$this->look_up_model->departmentList();
      $info=$this->requisition_model->get_info($requisition_id);
      $data['detail']=$this->po_model->getPRDetails($requisition_id);
      $data['department_id']=$info->department_id;
      $data['display']='format/addpo';
      $this->load->view('admin/master',$data);
  }

 function save($po_id=FALSE){
    $check=$this->po_model->save($po_id);
    if($check && !$po_id){
     $this->session->set_userdata('exception','Saved successfully');
     }elseif($check&& $po_id){
         $this->session->set_userdata('exception','Update successfully');
     }else{
       $this->session->set_userdata('exception','Submission Failed');
     }
    redirect("format/po/lists");
  }
  function delete($po_id=FALSE){
    $check=$this->po_model->delete($po_id);
      if($check){ 
         $this->session->set_userdata('exception','Delete successfully');
       }else{
         $this->session->set_userdata('exception','Delete Failed');
      }
    redirect("format/po/lists");
  }
  /////////////////////////////
  public function suggestions(){
      $term = $this->input->get('term', true);
      $for_department_id = $this->input->get('for_department_id', true);
      if (strlen($term) < 1 || !$term) {
          die("<script type='text/javascript'>setTimeout(function(){ window.top.location.href = '" . base_url('dashboard') . "'; }, 10);</script>");
      }
      $rows = $this->look_up_model->getdepartmentwiseItem($for_department_id,$term);
      if ($rows){
          $c = str_replace(".", "", microtime(true));
          $r = 0;
          foreach ($rows as $row) {
            $product_name="$row->product_name";
              $pr[] = array('id' => ($c + $r), 'product_id' => $row->product_id,'safety_qty' => $row->minimum_stock, 'label' => $row->product_name . " (" . $row->product_code . ")". " (Stock=" . $row->main_stock . ")",'category_name' => $row->category_name ,'unit_name' => $row->unit_name,'product_name' =>$product_name ,'product_code' => $row->product_code, 'unit_price' => $row->unit_price,'image_link' => $row->product_image, 'stock' =>$row->main_stock, 'currency' =>$row->currency);
              $r++;
          }
          header('Content-Type: application/json');
          die(json_encode($pr));
          exit;
      }else{
          $dsad='';
          header('Content-Type: application/json');
          die(json_encode($dsad));
          exit;
      }
  }
  function viewforapproved($po_id=FALSE){
      $data['show']=1;
      $data['info']=$this->po_model->get_info($po_id);
      $data['detail']=$this->po_model->getDetails($po_id);
      $data['heading']='PO/WO Information';
      $data['display']='format/woviewhtml';
      $this->load->view('admin/master',$data);
  }
  
  function submit($po_id=FALSE){
    $data['info']=$this->po_model->get_info($po_id); 
    $department_id=$data['info']->department_id;
    $emailaddress="golam.mostofa@bdventura.com";
    $subject="PO Approval Notification";
    $message=$this->load->view('po_approval_email', $data,true); 
  $this->smail->sendmail($emailaddress,$subject,$message);
  ////////////////////////
  $check=$this->po_model->submit($po_id);
    if($check){ 
      $this->session->set_userdata('exception','Send successfully');
     }else{
      $this->session->set_userdata('exception','Send Failed');
    }
  redirect("format/po/lists");
  }

  //////////////////////
  function deleteitem(){
    $po_id=$this->input->post('po_id');
    $product_id=$this->input->post('product_id');
    $chkiteminfo=$this->db->query("SELECT * FROM po_item_details 
          WHERE po_id=$po_id AND product_id=$product_id")->row();

      if(count($chkiteminfo)>0){
       $textpo.=" Remove this item ".$chkiteminfo->product_name." qty ".$chkiteminfo->required_qty."<br>";
      }
     if($textpo!=''){
      $data4['update_text']=$textpo;
      $data4['update_date']=date('Y-m-d');
      $data4['po_id']=$po_id;
      $this->db->insert('po_update_info',$data4);
     }
     $this->db->WHERE('po_id',$po_id);
     $this->db->WHERE('product_id',$product_id);
     $this->db->delete('po_item_details');
    echo TRUE;
  }
  function rejected($po_id=FALSE){
    $check=$this->po_model->rejected($po_id);
      if($check){ 
        $this->session->set_userdata('exception','Reject successfully');
       }else{
        $this->session->set_userdata('exception','Failed');
      }
    redirect("format/purhrequisn/lists");
  }
   
}