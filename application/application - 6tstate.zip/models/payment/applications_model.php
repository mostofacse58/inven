<?php
class Applications_model extends CI_Model {
  public function get_count(){
    $condition=' ';
    if($_GET){
      if($this->input->get('applications_no')!=''){
        $applications_no=$this->input->get('applications_no');
        $condition=$condition."  AND pm.applications_no='$applications_no' ";
      }
      if($this->input->get('pay_to_id')!='All'){
        $pay_to_id=$this->input->get('pay_to_id');
        $condition=$condition."  AND pm.pay_to_id='$pay_to_id' ";
      }
      if($this->input->get('from_date')!=''&&$this->input->get('to_date') !=' '){
        $from_date=$this->input->get('from_date');
        $to_date=$this->input->get('to_date');
        $condition.=" AND pm.applications_date BETWEEN '$from_date' AND '$to_date'";
      }
     }
    $department_id=$this->session->userdata('department_id');
    $query=$this->db->query("SELECT pm.*,d.department_name,
    	u.user_name, p.pay_to_name
      FROM  payment_application_master pm 
      LEFT JOIN department_info d ON(pm.department_id=d.department_id)
      LEFT JOIN payment_to_info p ON(pm.pay_to_id=p.pay_to_id) 
      LEFT JOIN user u ON(u.id=pm.prepared_by) 
      WHERE pm.to_department_id=$department_id $condition");
       
     $data = count($query->result());
     return $data;
    }
  function lists($limit,$start) {
    $condition=' ';
    if($_GET){
      if($this->input->get('applications_no')!=''){
        $applications_no=$this->input->get('applications_no');
        $condition=$condition."  AND pm.applications_no='$applications_no' ";
      }
    
      if($this->input->get('pay_to_id')!='All'){
        $pay_to_id=$this->input->get('pay_to_id');
        $condition=$condition."  AND pm.pay_to_id='$pay_to_id' ";
      }
      if($this->input->get('from_date')!=''&&$this->input->get('to_date') !=' '){
        $from_date=$this->input->get('from_date');
        $to_date=$this->input->get('to_date');
        $condition.=" AND pm.applications_date BETWEEN '$from_date' AND '$to_date'";
      }
     }
  $department_id=$this->session->userdata('department_id');
    $result=$this->db->query("SELECT pm.*,d.department_name,
    	u.user_name, p.pay_to_name
      FROM  payment_application_master pm 
      LEFT JOIN department_info d ON(pm.department_id=d.department_id)
      LEFT JOIN payment_to_info p ON(pm.pay_to_id=p.pay_to_id) 
      LEFT JOIN user u ON(u.id=pm.prepared_by) 
      WHERE pm.to_department_id=$department_id  
      $condition
      ORDER BY pm.payment_id 
      DESC LIMIT $start,$limit")->result();
 
    return $result;
  }
  function get_info($payment_id){
     $result=$this->db->query("SELECT pm.*,
      d.department_name,d.dept_head_email,u.user_name,u.email_address,
     	u.mobile,p.pay_to_name,
      u2.user_name as checked_by,u3.user_name as approved_by,
      d2.department_name as acc_department_name,d2.dept_head_email as acc_dept_head_email,
      u4.user_name as received_by
      FROM  payment_application_master pm 
      LEFT JOIN department_info d ON(pm.to_department_id=d.department_id)
      LEFT JOIN department_info d2 ON(pm.department_id=d2.department_id)
      INNER JOIN payment_to_info p ON(pm.pay_to_id=p.pay_to_id)
      LEFT JOIN user u ON(u.id=pm.prepared_by) 
      LEFT JOIN user u2 ON(u2.id=pm.checked_by)
      LEFT JOIN user u3 ON(u3.id=pm.approved_by)
      LEFT JOIN user u4 ON(u4.id=pm.received_by)
      WHERE pm.payment_id=$payment_id")->row();
    return $result;
    }
    public function getDetails($payment_id=''){
     $result=$this->db->query("SELECT a.*
          FROM payment_application_detail a
          WHERE a.payment_id=$payment_id 
          ORDER BY a.detail_id ASC")->result();
     return $result;
    }
    public function getDetails1($payment_id=''){
     $result=$this->db->query("SELECT a.*,p.department_name
          FROM payment_dept_amount a
          INNER JOIN pa_dept_code p ON(p.dcode=a.dcode)
          WHERE a.payment_id=$payment_id 
          ORDER BY a.id ASC")->result();
     return $result;
    }

    function save($payment_id) {
        $data=array();
        $data['pay_to_id']=$this->input->post('pay_to_id');
        $data['applications_date']=alterDateFormat($this->input->post('applications_date'));
        $data['to_department_id']=$this->session->userdata('department_id');
        $data['description']=$this->input->post('description');
        $data['vat_add_per']=$this->input->post('vat_add_per');
        $data['vat_add_amount']=$this->input->post('vat_add_amount');
        $data['ait_add_per']=$this->input->post('ait_add_per');
        $data['ait_add_amount']=$this->input->post('ait_add_amount');
        $data['sub_total']=$this->input->post('sub_total');
        $data['vat_less_per']=$this->input->post('vat_less_per');
        $data['vat_less_amount']=$this->input->post('vat_less_amount');
        $data['ait_less_per']=$this->input->post('ait_less_per');
        $data['ait_less_amount']=$this->input->post('ait_less_amount');
        $data['other_note']=$this->input->post('other_note');
        $data['other_plus_minus']=$this->input->post('other_plus_minus');
        $data['other_amount']=$this->input->post('other_amount');
        $data['total_amount']=$this->input->post('total_amount');
        $data['pay_term']=$this->input->post('pay_term');
        $data['prepared_by']=$this->session->userdata('user_id');
        $data['prepared_date']=date('Y-m-d');
        ////////////////////////////////////////
        
        if($payment_id==FALSE){
          $applications_no=$this->db->query("SELECT IFNULL(MAX(payment_id),0) as applications_no
               FROM payment_application_master WHERE 1")->row('applications_no');
          $applications_no ='BDPA-'.str_pad($applications_no + 1, 6, '0', STR_PAD_LEFT);
          $data['applications_no']=$applications_no;
          $query=$this->db->insert('payment_application_master',$data);
          $payment_id=$this->db->insert_id();
        }else{
          $this->db->WHERE('payment_id',$payment_id);
          $query=$this->db->UPDATE('payment_application_master',$data);
          $this->db->WHERE('payment_id',$payment_id);
          $this->db->delete('payment_application_detail');
          $this->db->WHERE('payment_id',$payment_id);
          $this->db->delete('payment_dept_amount');
        } 
        $bill_description=$this->input->post('bill_description');
        $amount=$this->input->post('amount');
        $i=0;
        foreach ($bill_description as $value) {
           $data1['bill_description']=$value;
           $data1['payment_id']=$payment_id;
           $data1['amount']=$amount[$i];
           $query=$this->db->insert('payment_application_detail',$data1);
           $i++;
         }
        $dcode=$this->input->post('dcode');
        $damount=$this->input->post('damount');
        $i=0;
        foreach ($dcode as $value) {
           $data2['dcode']=$value;
           $data2['payment_id']=$payment_id;
           $data2['damount']=$damount[$i];
           $query=$this->db->insert('payment_dept_amount',$data2);
           $i++;
         }
      return $query;
    }
  
    function delete($payment_id) {
      $this->db->WHERE('payment_id',$payment_id);
      $query=$this->db->delete('payment_application_detail');
      $this->db->WHERE('payment_id',$payment_id);
      $query=$this->db->delete('payment_application_master');
      return $query;
     }

  
   function approved($payment_id) {
        $this->db->WHERE('payment_id',$payment_id);
        $query=$this->db->Update('payment_application_master',array('status'=>2));
        return $query;
     }
  function submit($payment_id) {
    $this->db->WHERE('payment_id',$payment_id);
    $query=$this->db->Update('payment_application_master',array('status'=>2));
    return $query;
 }
 function decisions($payment_id) {
      $data=array();
      $data['status']=$this->input->post('status');
      $data['comment_note']=$this->session->userdata('user_name').":".$this->input->post('comment_note');
      $this->db->WHERE('payment_id',$payment_id);
      $query=$this->db->Update('payment_application_master',$data);
      return $query;
   }

  
}
