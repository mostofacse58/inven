<?php
class gatepass_model extends CI_Model {
  public function get_count(){
    $condition=' ';
    if($_GET){
      if($this->input->get('asset_encoding')!=''){
        $asset_encoding=$this->input->get('asset_encoding');
        $condition=$condition."  AND (pd.asset_encoding LIKE '%$asset_encoding%' OR pd.ventura_code LIKE '%$asset_encoding%' OR p.product_code LIKE '%$asset_encoding%') ";
      }
      
     }
    $department_id=$this->session->userdata('department_id');
      $query=$this->db->query("SELECT sim.* FROM gatepass_costing sim
        INNER JOIN product_detail_info pd ON(sim.product_detail_id=pd.product_detail_id)
        INNER JOIN product_info p ON(p.product_id=pd.product_id)
        WHERE 1  $condition");
      $data = count($query->result());
      return $data;
    }
  function lists($limit,$start) {
    $department_id=$this->session->userdata('department_id');
    $condition=' ';
    if($_GET){
      if($this->input->get('asset_encoding')!=''){
        $asset_encoding=$this->input->get('asset_encoding');
        $condition=$condition."  AND (pd.asset_encoding LIKE '%$asset_encoding%' OR pd.ventura_code LIKE '%$asset_encoding%' OR p.product_code LIKE '%$asset_encoding%') ";
      }
      if($this->input->get('location_name')!=''){
        $location_name=$this->input->get('location_name');
        $condition=$condition."  AND sim.location_name='$location_name' ";
      }
     }
     $result=$this->db->query("SELECT sim.*,pd.*,p.product_name,p.product_code
      FROM gatepass_costing sim
      INNER JOIN product_detail_info pd ON(sim.product_detail_id=pd.product_detail_id)
      INNER JOIN product_info p ON(p.product_id=pd.product_id)
      LEFT JOIN user u ON(u.id=sim.user_id) 
      WHERE 1  $condition
      ORDER BY sim.gatepass_id DESC LIMIT $start,$limit")->result();
    return $result;
  }
    function get_info($gatepass_id){
        $result=$this->db->query("SELECT sim.*,pd.*,p.product_name,p.product_code,
          c.category_name
          FROM gatepass_costing sim
          INNER JOIN product_detail_info pd ON(sim.product_detail_id=pd.product_detail_id)
          INNER JOIN product_info p ON(p.product_id=pd.product_id)
          INNER JOIN category_info c ON(p.category_id=c.category_id)
          LEFT JOIN user u ON(u.id=sim.user_id) 
          WHERE 1 AND sim.gatepass_id=$gatepass_id")->row();
        return $result;
    }
  
    function save($gatepass_id) {
      $department_id=$this->session->userdata('department_id');
        $data=array();
        $data['product_detail_id']=$this->input->post('product_detail_id');
        $data['location_name']=$this->input->post('location_name');
        $data['gatepass_date']=alterDateFormat($this->input->post('gatepass_date'));
        $data['problem_details']=$this->input->post('problem_details');
        $data['gatepass_no']=$this->input->post('gatepass_no');
        $data['out_quantity']=$this->input->post('out_quantity');
        $data['issuer_to_name']=$this->input->post('issuer_to_name');
        $data['user_id']=$this->session->userdata('user_id');
        $data['service_details']=$this->input->post('service_details');
        $data['in_quantity']=$this->input->post('in_quantity');
        $data['servicing_cost']=$this->input->post('servicing_cost');
        if($gatepass_id==FALSE){
          $query=$this->db->insert('gatepass_costing',$data);
          ///////////////////////
        }else{
          $this->db->WHERE('gatepass_id',$gatepass_id);
          $query=$this->db->update('gatepass_costing',$data);
        }
      return $query;
    }
   
    function underService(){
      $gatepass_id=$this->input->post('gatepass_id1');
      $data2['gatepass_status']=3;
      $data2['return_date']=alterDateFormat($this->input->post('return_date1'));
      $data2['return_note']=$this->input->post('return_note1');
      $data2['take_over_status']=2;
      $this->db->where('gatepass_id', $gatepass_id);
      $this->db->update('gatepass_costing',$data2);
      //////////////////////////////////////////////
      $product_detail_id=$this->db->query("SELECT product_detail_id 
        FROM gatepass_costing 
        WHERE gatepass_id=$gatepass_id")->row('product_detail_id');
      $data1['it_status']=3;
      $data1['takeover_date']=alterDateFormat($this->input->post('return_date'));
      $data1['remarks']=$this->input->post('return_note');
      $this->db->WHERE('product_detail_id',$product_detail_id);
      $this->db->update('product_detail_info',$data1);
      return true;

    }
    function returndate(){
        $gatepass_id=$this->input->post('gatepass_id');
        $data2['gatepass_status']=2;
        $data2['return_date']=alterDateFormat($this->input->post('return_date'));
        $data2['return_note']=$this->input->post('return_note');
        $data2['take_over_status']=2;
        $this->db->where('gatepass_id', $gatepass_id);
        $this->db->update('gatepass_costing',$data2);
        //////////////////////////////////////////////
        $product_detail_id=$this->db->query("SELECT product_detail_id FROM gatepass_costing 
          WHERE gatepass_id=$gatepass_id")->row('product_detail_id');
        $data1['it_status']=2;
        $data1['takeover_date']=alterDateFormat($this->input->post('return_date'));
        $data1['remarks']=$this->input->post('return_note');
          $this->db->WHERE('product_detail_id',$product_detail_id);
          $query=$this->db->update('product_detail_info',$data1);
        /////////////////////////////////////////////
      return $query;

    }
  
    function delete($gatepass_id) {
        $this->db->WHERE('gatepass_id',$gatepass_id);
        $query=$this->db->delete('gatepass_costing');
        return $query;
    }
  

  
}
