<html>
<header>
<style type="text/css">
body {
   padding: 3px;
   font-size:13px;
   font-family: 'Hiragino Kaku Gothic Pro', 'WenQuanYi Zen Hei', '微軟正黑體', '蘋果儷中黑', Helvetica, Arial, sans-serif;
    }
.tg  {border-collapse:collapse;border-spacing:0;width:100%}
.tg td{
  font-family: 'Hiragino Kaku Gothic Pro', 'WenQuanYi Zen Hei', '微軟正黑體', '蘋果儷中黑', Helvetica, Arial, sans-serif;
  font-size:12px;padding:2px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;text-align: center;}
.tg th{
  font-family: 'Hiragino Kaku Gothic Pro', 'WenQuanYi Zen Hei', '微軟正黑體', '蘋果儷中黑', Helvetica, Arial, sans-serif;
  font-size:12px;font-weight:normal;padding:2px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;font-weight: bold}
.tg .tg-s6z2{text-align:center}
.tg .tg-right{text-align:right;vertical-align:top;padding-right: 20px}
hr{margin: 5px}
.tg1  {border-collapse:collapse;border-spacing:0;width:100%}
.tg1 td{
  font-family: 'Hiragino Kaku Gothic Pro', 'WenQuanYi Zen Hei', '微軟正黑體', '蘋果儷中黑', Helvetica, Arial, sans-serif;
  font-size:12px;padding:2px;overflow:hidden;word-break:normal;line-height: 18px;overflow: hidden;}
</style>
</header>
<body>

<div  style="width:100%;float:left;font-size: 30px;text-align: center;overflow:hidden;margin:0;margin-top: 0px;">
<p style="margin:0px 0px;color: #538FD4">
<b><?php echo $this->session->userdata('company_name'); ?></b></p>
</div>
 <div style="width:100%;overflow:hidden;text-align:center;margin-top: 0px;">
<p style="line-height: 20px;padding: 0px 5px;font-size: 18px" >
  <b>PAYMENT APPLICATION  </b></p>
</div>
<hr style="margin-top: 0px">
<table style="width: 100%">
  <tr>
    <th style="width:20%;text-align: left" > 
     To:  </th>
    <th style="text-align: left" colspan="3"> 
      <?php if(isset($info)) echo $info->acc_department_name; ?>
     </th>
   </tr>
  <tr>
    <th style="width:20%;text-align: left" > 
     Dept:  </th>
    <th style="width:50%;text-align: left"> 
      <?php echo $this->session->userdata('company_name'); ?>
     </th>
    <th style="width:15%text-align: left" > 
    Date: </th>
    <th style="width:15%">
      <?php if(isset($info)) echo  date("j-M-Y", strtotime("$info->applications_date")); ?>
    </th>
  </tr>
  <tr>
    <th style="width:20%;text-align: left" > 
     Pay To:</th>
    <th style="text-align: left" colspan="3"> 
      <?php if(isset($info)) echo $info->pay_to_name; ?>
     </th>
   </tr>
 
 
</table>
<br>

<table class="tg"  style="overflow: hidden;">
  <thead>
  <tr>
    <th style="width:40%;text-align:center">Description</th>
    <th style="width:20%;text-align:center">Percentage</th>
    <th class="tg-right" style="width:20%;">Amount</th>
  </tr>
</thead>
<tbody>
  <?php
  if(isset($detail)){
	   $i=1;
	  foreach($detail as $value){ 

	  ?>
  <tr>
    <td class="tg-s6z2"><?php echo $value->bill_description;  ?></td>
    <td class=""></td>
    <td class="tg-right"><?php echo $value->amount; ?></td>
  </tr>
   <?php }
 } ?>
 <?php if($info->vat_add_per!=0){ ?>
   <tr>
    <td class="tg-s6z2">Add. VAT</td>
    <td><?php if(isset($info)) echo $info->vat_add_per; ?>%</td>
    <td class="tg-right"><?php if(isset($info)) echo $info->vat_add_amount; ?></td>
  </tr>
<?php } ?>
<?php if($info->ait_add_per!=0){ ?>
   <tr>
    <td class="tg-s6z2">Add. AIT</td>
    <td><?php if(isset($info)) echo $info->ait_add_per; ?>%</td>
    <td class="tg-right"><?php if(isset($info)) echo $info->ait_add_amount; ?></td>
  </tr>
<?php } ?>

<?php if($info->vat_add_per!=0||$info->ait_add_per!=0){ ?>
   <tr>
    <th class="tg-s6z2">Adjusted Bill Amount</th>
    <td></td>
    <th class="tg-right"><?php if(isset($info)) echo $info->sub_total; ?></th>
  </tr>
<?php } ?>

<?php if($info->vat_less_per!=0){ ?>
   <tr>
    <td class="tg-s6z2">Less. VAT</td>
    <td><?php if(isset($info)) echo $info->vat_less_per; ?>%</td>
    <td class="tg-right"><?php if(isset($info)) echo $info->vat_less_amount; ?></td>
  </tr>
<?php } ?>
<?php if($info->ait_less_per!=0){ ?>
   <tr>
    <td class="tg-s6z2">Less. AIT</td>
    <td><?php if(isset($info)) echo $info->ait_less_per; ?>%</td>
    <td class="tg-right"><?php if(isset($info)) echo $info->ait_less_amount; ?></td>
  </tr>
<?php } ?>
<?php if($info->other_amount!=0){ ?>
   <tr>
    <td class="tg-s6z2"><?php if(isset($info)) echo $info->other_note; ?></td>
    <td><?php if(isset($info)) echo $info->other_plus_minus; ?></td>
    <td class="tg-right"><?php if(isset($info)) echo $info->other_amount; ?></td>
  </tr>
<?php } ?>
   <tr>
    <th class="tg-s6z2"></th>
    <th>Net Payment:</th>
    <th class="tg-right"><?php if(isset($info)) echo $info->total_amount; ?></th>
  </tr>


</tbody>
</table>
<p style="text-align: left;width: 100%;float: left;overflow: hidden;margin-top: 10px;font-weight: bold;">
<?php
  if(isset($detail1)){
     $i=1;
    foreach($detail1 as $value){ 
    ?>
  
    <?php echo "$value->department_name: $value->damount;";  ?>
  
  <?php } } ?>
  </p>

<p style="text-align: left;width: 100%;float: left;overflow: hidden;margin-top: 1px;font-weight: bold;">
 Amount In Word: <?php if(isset($info)) echo number_to_word($info->total_amount); ?>
</p> 
<p style="text-align: left;width: 100%;float: left;overflow: hidden;margin-top: 1px;">
 Description : <?php if(isset($info)) echo $info->description; ?>
</p> 
<p style="text-align: left;width: 100%;float: left;overflow: hidden;margin-top: 1px;font-weight: bold;">
 Payment: <?php if(isset($info)) echo $info->pay_term; ?>
</p>

<br><br>
<table class="tg1" style="overflow: hidden;">
  <tr>
  <td>&nbsp;</td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
  <tr>
  <td style="width:25%;text-align:left;">
    <?php if($info->status>=1) echo "$info->user_name"; ?></td>

  <td style="width:25%;text-align:center;">
    <?php if($info->status>=4&&$info->status!=8) echo "$info->checked_by"; ?></td>
  <td style="width:25%;text-align:center;">
  <?php if($info->status>=5&&$info->status!=8) echo "$info->received_by"; ?></td>
  <td style="width:25%;text-align:right;">
  <?php if($info->status>=6&&$info->status!=8) echo "$info->approved_by"; ?></td>
  </tr>
  <tr>
  <td style="width:20%;text-align:left;">
    <?php if($info->status>=1) echo findDate($info->prepared_date); ?></td>

  <td style="width:20%;text-align:center;">
    <?php if($info->status>=4&&$info->status!=8) echo findDate($info->checked_date); ?></td>
  <td style="width:20%;text-align:center;">
  <?php if($info->status>=5&&$info->status!=8) echo findDate($info->received_date); ?></td>
  <td style="width:20%;text-align:right;">
    <?php if($info->status>=6&&$info->status!=8) echo findDate($info->approved_date); ?></td>
  </tr>
  <tr>
  <td style="text-align:left;font-size: 15px;line-height: 5px">---------------</td>
  <td style="text-align:center;font-size: 15px;line-height: 5px">---------------</td>
  <td style="text-align:center;font-size: 15px;line-height: 5px">----------------</td>
  <td style="text-align:right;font-size: 15px;line-height: 5px">----------------</td>
  </tr>
  <tr>
  <td style="text-align:left;">Prepared By:</td>
  <td style="text-align:center;">Checked By: </td>
  <td style="text-align:center;">Received By</td>
  <td style="text-align:right;">Approved By</td>
  </tr>
</table>
</body>
<html>