<div class="page-header">
	<h1>
		Generated QR Code dd
	</h1>
</div><!-- /.page-header -->
<div class="row">
    <div class="col-xs-12">
        <!-- PAGE CONTENT BEGINS --> 
          

        <div class="row">
            <div class="col-md-6 col-md-offset-3"> 
                <img src="<?php echo $this->look_up_model->qcode_function(); ?>"> 
            </div> 
        </div> 

        <div class="space-22"></div>


        <div class="row center">
            <div class="col-md-6 col-md-offset-3"> 
                <button class="btn btn-info btn-sm btn-round" type="button">
                    <i class="ace-icon fa fa-check"></i>
                    Print Queuevite Card
                </button>

                <button class="btn btn-success btn-sm btn-round" type="button">
                    <i class="ace-icon fa fa-download"></i>
                    Download Queuevite Card
                </button>
                
            </div>
        </div>  

        </form>  
        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->
</div><!-- /.row -->