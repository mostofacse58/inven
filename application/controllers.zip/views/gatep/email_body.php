<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear sir, <br>
Good day. 
You have one (<?php if($info->gatepass_type==1) echo "Material"; else echo "Finished Goods"; ?>) gate pass pending for approval. please check.
<br><br>
Thanks by <br>
Ventura IT <br><br>
This is auto generated email from Ventura Online Gate Pass System Software. No Need to Reply.
</body>
</html>