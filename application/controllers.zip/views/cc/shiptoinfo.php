<div class="row">
  <div class="col-xs-12">
   <div class="box box-primary">
            <div class="box-header">
              <div class="widget-block">
             
<div class="widget-head">
<h5><?php echo ucwords($heading); ?></h5>
<div class="widget-control pull-right">

</div>
</div>
</div>
</div>
<div class="box box-info">
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" action="<?php echo base_url();?>cc/shipto/save<?php if(isset($info)) echo "/$info->ship_id"; ?>" method="POST" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Ship To Name<span style="color:red;">  *</span></label>
                  <div class="col-sm-3">
                    <input type="text" name="ship_name" class="form-control" placeholder="Ship To Name" value="<?php if(isset($info->ship_name)) echo $info->ship_name; else echo set_value('ship_name'); ?>" autofocus>
                   <span class="error-msg"><?php echo form_error("ship_name");?></span>
                  </div>
                  <label class="col-sm-2 control-label">Attention<span style="color:red;"> </span></label>
                  <div class="col-sm-3">
                    <input type="text" name="ship_attention" class="form-control" placeholder=" ship_attention" value="<?php if(isset($info->ship_attention)) echo $info->ship_attention; else echo set_value('ship_attention'); ?>" autofocus>
                   <span class="error-msg"><?php echo form_error("ship_attention");?></span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Telephone<span style="color:red;">  *</span></label>
                  <div class="col-sm-3">
                    <input type="text" name="ship_telephone" class="form-control" placeholder=" Telephone" value="<?php if(isset($info->ship_telephone)) echo $info->ship_telephone; else echo set_value('ship_telephone'); ?>" autofocus>
                   <span class="error-msg"><?php echo form_error("ship_telephone");?></span>
                  </div>
                  <label class="col-sm-2 control-label">Email<span style="color:red;"> </span></label>
                  <div class="col-sm-3">
                    <input type="text" name="ship_email" class="form-control" placeholder="ship_email" value="<?php if(isset($info->ship_email)) echo $info->ship_email; else echo set_value('ship_email'); ?>" autofocus>
                   <span class="error-msg"><?php echo form_error("ship_email");?></span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Address<span style="color:red;"> *</span></label>
                  <div class="col-sm-3">
                    <textarea type="text" name="ship_address" class="form-control" placeholder="Address" value=""><?php if(isset($info->ship_address)) echo $info->ship_address; else echo set_value('ship_address'); ?></textarea>
                   <span class="error-msg"><?php echo form_error("ship_address");?></span>
                  </div>
                  <div class="col-sm-2">
                <button type="submit" class="btn btn-success pull-left">SAVE</button>
                </div>
                </div>

              <!-- /.box-body -->
            </form>
          </div>
            <!-- /.box-header -->
            <div class="box-body box">
              <div class="col-md-12">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th style="width:4%" class="text-center">SN</th>
                    <th style="width:20%">Name</th>
                    <th style="width:15%">Attention</th>
                    <th style="width:15%">Telephone</th>
                    <th style="width:15%">Email</th>
                    <th style="width:20%" class="text-center">Address</th>
                    <th  style="text-align:center;width:8%">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  if($list&&!empty($list)): 
                    $i=1;
                      foreach($list as $row):
                          ?>
                      <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo $row->ship_name;?></td>
                        <td><?php echo $row->ship_attention;?></td>
                        <td><?php echo $row->ship_telephone;?></td>
                        <td><?php echo $row->ship_email;?></td>
                        <td><?php echo $row->ship_address;?></td>
                        <td style="text-align:center">
                          <a class="btn btn-success" href="<?php echo base_url()?>cc/shipto/edit/<?php echo $row->ship_id;?>"><i class="fa fa-edit tiny-icon"></i></a>
                          &nbsp;&nbsp;&nbsp;&nbsp;                                        
                        <a href="#" class="btn btn-danger delete" data-pid="<?php echo $row->ship_id;?>"><i class="fa fa-trash-o tiny-icon"></i></a>
                        </td>
                      </tr>
                      <?php
                      endforeach;
                  endif;
                  ?>
                  </tbody>
              </table>
            </div>
          </div>
            <!-- /.box-body -->
          </div>
        </div>
 </div>
 <div class="modal modal-danger fade bs-example-modal-sm " tabindex="-1" role="dialog" id="deleteMessage" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title" id="mySmallModalLabel"><i class="fa fa-bell-o"></i> System Alert</h4>
        </div>
        <div class="modal-body">
        Sorry, this Issue To can't be deleted!!
        </div>
      </div><!-- /.modal-content -->
    </div>
  </div>

<script>
$(document).ready (function(){
  ///////////////////  CHECK BEFOR DELETING ATTACHEMNT//////////////////////
$(".delete").click(function(e){
  job=confirm("Are you sure you want to delete this information?");
   if(job==true){
  e.preventDefault();
  var rowId=$(this).data('pid');
  var url=$(this).attr("href");
  $.ajax({
   type:"GET",
   url:"<?php echo base_url();?>cc/shipto/checkDelete/"+rowId,
     success:function(data){
      if(data=="EXISTS"){
        $("#deleteMessage").modal("show");
      }else{
        location.href="<?php echo base_url();?>cc/shipto/delete/"+rowId;
     }
},
error:function(){
  console.log("failed");
}
});
}
});
});//jquery ends here
</script>
